# FuseCode Headless

FuseCode Headless exposes a repository-scoped coding-agent session through a
small browser UI. It does not require the macOS desktop application, so it can
run on a workstation, server, container, or remote development machine.

Build and start it from the repository root:

```sh
make headless
FUSECODE_HEADLESS_TOKEN="choose-a-secret" \
FUSECODE_HEADLESS_WORKDIR="/path/to/repository" \
./fusecode-headless
```

Open the URL printed at startup. The access token is placed in the URL fragment
and removed from the address bar by the client. Set `FUSECODE_HEADLESS_HOST` to
bind to a non-loopback interface and `FUSECODE_HEADLESS_PORT` to change the
default port (`8095`). Use a trusted reverse proxy with TLS when exposing the
service over a network.

The server uses the installed CLI for the selected provider: `claude`, `codex`,
`cursor-agent`, `opencode`, `grok`, or `kimi`. Authentication remains owned by
those CLIs. Sessions are kept in memory and provider resume IDs are reused until
the server exits.
