# FuseCode remote relay

A tiny relay server that lets you drive the FuseCode desktop app from your
phone's browser over **WebSockets** — no polling, messages flow only when
something changes.

```
 phone browser  ◄──ws──►  relay server  ◄──ws──►  FuseCode desktop
                          (this dir)              (remote.v)
```

Each desktop is a **client** of the relay — it opens one outbound WebSocket, so
you never open a port on the machine running FuseCode. Put the relay anywhere the
phone can reach it (a small VPS, or just `localhost` on the same Wi‑Fi).

A relay token can contain multiple named desktops. The web client shows a machine
switcher and routes every action only to the selected machine. The Remote Access
dialog also stores multiple relay environments, each with its own URL and token.

## Ports

The relay listens on two ports:

| Port         | Default | Purpose                                          |
|--------------|---------|--------------------------------------------------|
| HTTP         | 8090    | serves the mobile page (path `/`)                |
| WebSocket    | 8091    | desktop + phone connect here (path `/ws`)        |

How the WebSocket endpoint is resolved from the HTTP base URL you enter:

- **Dev, explicit port** (`http://127.0.0.1:8090`) → `ws://127.0.0.1:8091/ws`
  (the WS listener is HTTP port + 1).
- **Prod, path-based endpoint** (`https://fusecode.app/remote`) →
  `wss://fusecode.app/remote/ws` — same origin and base path, port 443. Front the
  relay with a reverse proxy that routes `/remote/ws` to the WebSocket port and
  `/remote` to the HTTP port (see below). This is the desktop app's built-in
  default URL.

## Run it

```sh
v run server/                     # HTTP :8090, WS :8091
FUSECODE_REMOTE_PORT=9000 v run server/          # HTTP :9000, WS :9001
FUSECODE_REMOTE_WS_PORT=9443 v run server/       # override the WS port
```

Build a standalone binary for a server:

```sh
v -prod -o fusecode-relay server/
./fusecode-relay
```

## Connect

1. In the desktop app: **File ▸ Remote Access…**. It defaults to the hosted relay
   (`https://fusecode.app/remote`); set your own HTTP URL for a private/dev relay.
   Click **Enable**. The dialog shows a **token** and a ready‑made phone URL like
   `https://fusecode.app/remote/#abcd1234`.
2. Open that URL on your phone. The token rides in the URL fragment and is stored
   in `localStorage`, so you only paste it once.

## Production deployment

The checked-in deployment script cross-compiles the relay, installs it at
`/var/www/fusecode.app/remote` on the `vpm` SSH host, configures the
`fusecode-remote` systemd service and nginx routes, then verifies the endpoint:

```sh
v run server/deploy.vsh
```

It keeps backups of the live binary and host configuration and restores them if
the new service fails verification. The systemd unit restricts the relay's raw
listener ports to localhost; public traffic must pass through the TLS endpoint.

## Reverse proxy configuration

Terminate TLS at nginx or an upstream CDN and route by path — `/remote/ws` to the
WebSocket port and `/remote` to the HTTP port. The production nginx configuration
is checked in as `fusecode.app.nginx`; the relevant locations are:

```nginx
    location = /remote/ws {
        proxy_pass http://127.0.0.1:8091;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 3600s;
    }
    location = /remote {
        proxy_pass http://127.0.0.1:8090/;
    }
}
```

Both the desktop and the phone then use `https://fusecode.app/remote`.

## Auth

A single shared token guards every connection.

- Default: **trust‑on‑first‑use** — the relay adopts the token from the desktop's
  first `hello`. A client with a different token is closed (code 1008).
- Locked: set `FUSECODE_REMOTE_TOKEN=…` before starting the relay to pin it.

Always serve the relay over TLS when it's exposed to the internet (see
*Production* above) — the token is a bearer secret.

## Protocol (JSON text frames over WS)

Each frame carries a `type`. Auth token is on the first `hello` (and validated on
every subsequent frame).

| Direction        | `type`                | Payload                                  |
|------------------|-----------------------|------------------------------------------|
| desktop → relay  | `hello`               | `{role:"desktop", token, machine_id, machine_name}` |
| desktop → relay  | `snapshot`            | `{token, machine_id, selected_id, sessions, messages}` |
| relay → desktop  | `command`             | `{kind:"send"｜"select"｜"stop", session_id, text}` |
| relay → desktop  | `presence`            | `{client_active, want_session_id}`       |
| phone → relay    | `hello`               | `{role:"phone", token}`                  |
| phone → relay    | `machine`             | `{token, machine_id}`                    |
| phone → relay    | `send`/`select`/`stop`| `{token, machine_id, session_id, text}`  |
| phone → relay    | `pin_toggle`/`pin_up`/`pin_down` | `{token, machine_id, session_id}` |
| phone → relay    | `model`/`permission`  | `{token, machine_id, session_id, text}`  |
| phone → relay    | `source`/`script`     | `{token, machine_id, session_id, text}`  |
| relay → phone    | `state`               | `{online, machine_id, machines, selected_id, sessions, messages}` |

Wire structs live in `server/remote_server.v` (relay) and `remote.v` (desktop);
keep the two in sync.

The browser client exposes the same per-session model and permission choices as
the desktop, plus commit, push, pull-request, and discovered project-script
actions. Mutating controls are disabled while that session is running.
